package com.esign.controller;

import com.alibaba.fastjson2.JSONObject;
import com.esign.client.EsignClient;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
@RequestMapping("/api/esign")
public class EsignController {

    private final EsignClient esignClient;

    public EsignController(EsignClient esignClient) {
        this.esignClient = esignClient;
    }

    /**
     * GET 代理
     * 示例: GET /api/esign/doGet?path=/esign-signs/v1/signFlow/signUrls?signFlowId=xxx
     */
    @GetMapping("/doGet")
    public String doGet(@RequestParam String path) {
        return esignClient.doGet(path);
    }

    /**
     * POST 代理
     * 示例: POST /api/esign/doPost
     * body: { "path": "/esign-signs/v1/signFlow/createAndStart", "body": { ... } }
     */
    @PostMapping("/doPost")
    public String doPost(@RequestBody JSONObject request) {
        String path = request.getString("path");
        JSONObject body = request.getJSONObject("body");
        return esignClient.doPost(path, body);
    }

    /**
     * 文件上传代理
     * 示例: POST /api/esign/uploadFile
     * multipart: file=xxx.pdf, path=/file/v1/uploadWithAuth
     */
    @PostMapping("/uploadFile")
    public String uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("path") String path,
            @RequestParam(value = "extraBody", required = false) String extraBodyStr) throws IOException {

        Path tempFile = Files.createTempFile("esign_upload_", "_" + file.getOriginalFilename());
        file.transferTo(tempFile.toFile());

        try {
            JSONObject extraBody = (extraBodyStr != null && !extraBodyStr.isBlank())
                    ? JSONObject.parseObject(extraBodyStr)
                    : new JSONObject();

            extraBody.put("file", file.getOriginalFilename());

            return esignClient.uploadFile(path, tempFile.toFile(), extraBody);
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }
}
