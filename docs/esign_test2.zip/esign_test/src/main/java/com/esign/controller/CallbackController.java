package com.esign.controller;

import com.alibaba.fastjson2.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

/**
 * 电子签签署回调入口
 * 预留：接收签署完成回调 → 更新状态 → 下载归档 → 触发后续流程
 */
@RestController
@RequestMapping("/api/esign/callback")
public class CallbackController {

    private static final Logger log = LoggerFactory.getLogger(CallbackController.class);

    /**
     * 签署流程回调
     * 电子签平台在签署完成/状态变更时回调此接口
     */
    @PostMapping("/signNotify")
    public JSONObject signNotify(@RequestBody JSONObject payload) {
        log.info(">>> 收到签署回调: {}", payload.toJSONString());

        String signFlowId = payload.getString("signFlowId");
        String action = payload.getString("action");

        log.info("签署回调处理: signFlowId={}, action={}", signFlowId, action);

        // TODO: 根据业务需要实现
        // 1. 解析回调内容，校验签名
        // 2. 更新本地流程状态
        // 3. 若签署完成，触发文件下载归档
        // 4. 触发 finishFlow 和 deleteFile

        JSONObject resp = new JSONObject();
        resp.put("code", 200);
        resp.put("message", "success");
        return resp;
    }
}
