package com.esign.service;

import com.alibaba.fastjson2.JSONObject;
import com.esign.client.EsignClient;
import com.esign.exception.EsignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;

/**
 * 赛力斯人事签署场景业务服务
 * 按 saras-esign-flow 文档实现完整业务链路
 */
@Service
public class SarasHrEsignService {

    private static final Logger log = LoggerFactory.getLogger(SarasHrEsignService.class);

    private final EsignClient client;

    public SarasHrEsignService(EsignClient client) {
        this.client = client;
    }

    // ==================== A. 甲方信息同步 ====================

    /**
     * 查询内部组织详情
     * POST /manage/v1/innerOrganizations/detail
     *
     * @param orgCode 企业社会信用代码
     * @return 组织信息 (含 organizationId / organizationCode)
     */
    public JSONObject syncOrganization(String orgCode) {
        log.info(">>> 查询内部组织详情, orgCode={}", orgCode);

        JSONObject body = new JSONObject();
        body.put("organizationCode", orgCode);

        JSONObject result = JSONObject.parseObject(
                client.doPost("/manage/v1/innerOrganizations/detail", body));

        JSONObject data = result.getJSONObject("data");
        require(data != null, "组织详情", "data 为空");
        require(data.getString("organizationId") != null, "组织详情", "organizationId 缺失");

        log.info("组织ID: {}, 组织编码: {}",
                data.getString("organizationId"),
                data.getString("organizationCode"));
        return data;
    }

    /**
     * 查询组织授权印章列表
     * POST /seals/v1/sealcontrols/organizationSeals/list
     *
     * @param organizationId 组织ID (从 syncOrganization 获取)
     * @return 印章信息 (含 sealId / sealUserAccountId)
     */
    public JSONObject syncSeal(String organizationId) {
        log.info(">>> 查询组织授权印章列表, orgId={}", organizationId);

        JSONObject body = new JSONObject();
        body.put("organizationId", organizationId);

        JSONObject result = JSONObject.parseObject(
                client.doPost("/seals/v1/sealcontrols/organizationSeals/list", body));

        JSONObject data = result.getJSONObject("data");
        require(data != null, "印章列表", "data 为空");

        log.info("印章信息: {}", data);
        return data;
    }

    // ==================== B. 员工数据同步 ====================

    /**
     * 同步外部用户 (查询 → 不存在则新建 / 已存在则更新)
     */
    public JSONObject syncOuterUser(String name, String idCard, String mobile) {
        log.info(">>> 同步外部用户, name={}", name);

        // 先查
        JSONObject existUser = queryOuterUser(idCard, mobile);
        if (existUser != null) {
            log.info("用户已存在, accountId={}", existUser.getString("accountId"));
            // TODO: 按需判断信息是否变更，调用 updateOuterUser
            return existUser;
        }

        // 不存在则新建
        return createOuterUser(name, idCard, mobile);
    }

    /**
     * 查询外部用户详情
     * POST /manage/v1/outerUsers/detail
     */
    public JSONObject queryOuterUser(String idCard, String mobile) {
        JSONObject body = new JSONObject();
        body.put("idCard", idCard);
        body.put("mobile", mobile);

        try {
            String result = client.doPost("/manage/v1/outerUsers/detail", body);
            JSONObject json = JSONObject.parseObject(result);
            return json.getJSONObject("data");
        } catch (EsignException e) {
            log.info("用户不存在, 将创建新用户");
            return null;
        }
    }

    /**
     * 新建外部用户
     * POST /manage/v1/outerUsers/create
     */
    public JSONObject createOuterUser(String name, String idCard, String mobile) {
        log.info(">>> 新建外部用户, name={}", name);

        JSONObject body = new JSONObject();
        body.put("name", name);
        body.put("idCard", idCard);
        body.put("mobile", mobile);

        String result = client.doPost("/manage/v1/outerUsers/create", body);
        JSONObject json = JSONObject.parseObject(result);
        JSONObject data = json.getJSONObject("data");
        require(data != null, "新建用户", "data 为空");
        require(data.getString("accountId") != null, "新建用户", "accountId 缺失");

        log.info("新建用户成功, accountId={}", data.getString("accountId"));
        return data;
    }

    /**
     * 修改外部用户
     * POST /manage/v1/outerUsers/update
     */
    public JSONObject updateOuterUser(String accountId, String name, String mobile) {
        log.info(">>> 修改外部用户, accountId={}", accountId);

        JSONObject body = new JSONObject();
        body.put("accountId", accountId);
        body.put("name", name);
        body.put("mobile", mobile);

        String result = client.doPost("/manage/v1/outerUsers/update", body);
        return JSONObject.parseObject(result).getJSONObject("data");
    }

    // ==================== C. 文件上传 ====================

    /**
     * 上传合同文件 (两步: generateUploadUrl → uploadAndSpiltV2)
     *
     * @param pdfFile PDF 文件
     * @return fileKey
     */
    public String uploadContract(File pdfFile) {
        log.info(">>> 上传合同文件, file={}", pdfFile.getName());

        // 步骤1: 生成上传链接
        JSONObject urlBody = new JSONObject();
        urlBody.put("fileName", pdfFile.getName());
        urlBody.put("fileSize", pdfFile.length());

        JSONObject urlResult = client.generateUploadUrl(urlBody);
        JSONObject urlData = urlResult.getJSONObject("data");
        require(urlData != null, "生成上传链接", "data 为空");

        String fileKey = urlData.getString("fileKey");
        require(fileKey != null, "生成上传链接", "fileKey 缺失");
        log.info("生成上传链接成功, fileKey={}", fileKey);

        // 步骤2: 上传文件
        JSONObject uploadBody = new JSONObject();
        uploadBody.put("file", pdfFile.getName());
        uploadBody.put("fileKey", fileKey);

        client.uploadAndSpiltV2(pdfFile, uploadBody);
        log.info("文件上传成功");

        return fileKey;
    }

    // ==================== D. 发起签署 ====================

    /**
     * 使用文件一步发起签署
     * POST /esign-signs/v1/signFlow/createAndStart
     *
     * @return signFlowId
     */
    public String startEmployeeSignFlow(String fileKey, String subject, String businessNo,
                                         String signerAccountId) {
        log.info(">>> 发起签署流程, subject={}", subject);

        JSONObject body = new JSONObject();
        body.put("fileKey", fileKey);
        body.put("subject", subject);
        body.put("businessNo", businessNo);
        body.put("signerAccountId", signerAccountId);

        JSONObject result = client.createAndStart(body);
        JSONObject data = result.getJSONObject("data");
        require(data != null, "发起签署", "data 为空");

        String signFlowId = data.getString("signFlowId");
        require(signFlowId != null, "发起签署", "signFlowId 缺失");

        log.info("签署流程已创建, signFlowId={}", signFlowId);
        return signFlowId;
    }

    // ==================== E. 免登签署 ====================

    /**
     * 构建员工免登签署链接
     * getAccessToken → getSsoToken → 拼接签署 URL
     */
    public String buildSsoSignUrl(String signFlowId, String accountId) {
        log.info(">>> 构建免登签署链接, signFlowId={}", signFlowId);

        // 1. 获取 AccessToken
        JSONObject tokenBody = new JSONObject();
        tokenBody.put("signFlowId", signFlowId);
        tokenBody.put("accountId", accountId);

        JSONObject tokenResult = client.getAccessToken(tokenBody);
        JSONObject tokenData = tokenResult.getJSONObject("data");
        require(tokenData != null, "获取AccessToken", "data 为空");

        String accessToken = tokenData.getString("accessToken");
        require(accessToken != null, "获取AccessToken", "accessToken 缺失");
        log.info("accessToken: {}", accessToken);

        // 2. 获取 ssoToken
        JSONObject ssoBody = new JSONObject();
        ssoBody.put("accessToken", accessToken);
        ssoBody.put("accountId", accountId);

        JSONObject ssoResult = client.getSsoToken(ssoBody);
        JSONObject ssoData = ssoResult.getJSONObject("data");
        require(ssoData != null, "获取SsoToken", "data 为空");

        String ssoToken = ssoData.getString("ssoToken");
        require(ssoToken != null, "获取SsoToken", "ssoToken 缺失");
        log.info("ssoToken: {}", ssoToken);

        // 3. 获取签署链接
        JSONObject urlsResult = client.getSignUrls(signFlowId);
        JSONObject urlsData = urlsResult.getJSONObject("data");
        require(urlsData != null, "获取签署链接", "data 为空");

        String signUrl = urlsData.getString("signUrl");
        require(signUrl != null, "获取签署链接", "signUrl 缺失");

        // 4. 拼接免登链接
        String ssoSignUrl = signUrl + (signUrl.contains("?") ? "&" : "?")
                + "ssoToken=" + ssoToken;

        log.info("免登签署链接: {}", ssoSignUrl);
        return ssoSignUrl;
    }

    // ==================== F. 公司静默签 ====================

    /**
     * 添加公司签署方 (静默盖章)
     * POST /esign-signs/v1/signFlow/signers/add
     */
    public JSONObject addCompanySilentSigner(String signFlowId, String organizationId,
                                              String sealId, String sealUserAccountId) {
        log.info(">>> 添加公司静默签署方, signFlowId={}", signFlowId);

        JSONObject body = new JSONObject();
        body.put("signFlowId", signFlowId);
        body.put("organizationId", organizationId);
        body.put("sealId", sealId);
        body.put("sealUserAccountId", sealUserAccountId);
        body.put("signType", "1"); // 静默签

        JSONObject result = client.addSigners(body);
        log.info("公司签署方添加成功");
        return result.getJSONObject("data");
    }

    // ==================== G. 完成与清理 ====================

    /**
     * 结束签署流程
     * POST /esign-signs/v1/signFlow/finish
     */
    public void finishContractFlow(String signFlowId) {
        log.info(">>> 结束签署流程, signFlowId={}", signFlowId);

        JSONObject body = new JSONObject();
        body.put("signFlowId", signFlowId);

        client.finishFlow(body);
        log.info("签署流程已结束");
    }

    /**
     * 删除上传的文件
     * POST /esign-docs/v1/cus/file/delete
     */
    public void deleteUploadedFile(String fileKey) {
        log.info(">>> 删除文件, fileKey={}", fileKey);

        JSONObject body = new JSONObject();
        body.put("fileKey", fileKey);

        client.deleteFile(body);
        log.info("文件已删除");
    }

    // ==================== 工具方法 ====================

    private void require(boolean condition, String step, String msg) {
        if (!condition) {
            throw new EsignException(step, step + "失败: " + msg);
        }
    }
}
