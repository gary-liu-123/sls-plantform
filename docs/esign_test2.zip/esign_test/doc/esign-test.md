```
# 赛力斯人事场景接口交互整理

## 1. 查询内部组织详情

**接口**：`/manage/v1/innerOrganizations/detail`  
**说明**：入参是企业社会信用代码，查出组织编码。  
**统一社会信用代码**：`915001066608898456`

### 功能描述
根据组织编码 / 组织账号 / 名称多个条件组合查询内部组织。根据名称模糊查询到的结果可能有多条组织记录，则返回匹配的组织列表，按创建时间倒序排序；查询条件不能全为空。

### 接口地址与请求方法
- 接口地址：`http(s)://{host}/manage/v1/innerOrganizations/detail`
- 请求方法：`POST`

### 请求参数

| 参数名称 | 参数类型 | 必选 | 参数位置 | 参数说明 |
|---|---|---:|---|---|
| organizationCode | string | 否 | body | 组织编码（本系统的组织唯一标识）。如果 `organizationCode`、`customOrgNo`、`licenseNo` 三者都有值，以 `organizationCode` 为准 |
| customOrgNo | string | 否 | body | 组织账号（客户系统的组织唯一标识）。如果 `organizationCode`、`customOrgNo`、`licenseNo` 三者都有值，以 `organizationCode` 为准 |
| name | string | 否 | body | 组织名称，支持模糊查询，当输入内容只有“公司、企业、组织、部门”4个词时进行提示：“不能只输入公司、企业、组织、部门进行搜索” |
| licenseNo | string | 否 | body | 证件号。如果 `organizationCode`、`customOrgNo`、`licenseNo` 三者都有值，以 `organizationCode` 为准 |
| licenseType | string | 否 | body | 证件类型：`CREDIT_CODE`（统一社会信用代码）、`REGIST_NUMBER`（工商注册号）、`OTHER`（其他）。默认 `CREDIT_CODE` |

### 响应参数

| 参数名称 | 参数类型 | 参数说明 |
|---|---|---|
| code | int | 业务码，200 表示成功，其他表示失败 |
| message | string | 描述信息 |
| data | object | 业务信息 |

### 请求示例

```json
{
  "customOrgNo": "ZUZHIZHANGHAO",
  "licenseNo": "证件号",
  "licenseType": "证件类型",
  "name": "组织名称",
  "organizationCode": "15a59878e82b4f3c8b29dc4a56372ba9"
}
```

### 响应示例

```
{
  "code": 200,
  "data": [
    {
      "customOrgNo": "ZUZHIZHANGHAO",
      "legalRepAccountNo": "DAIBIAORENZHANGHAO",
      "legalRepName": "法定代表人姓名",
      "legalRepUserCode": "95873831329a4a92a67618ff0a848986",
      "licenseNo": 123456789101112365,
      "licenseType": "CREDIT_CODE",
      "name": "组织名称",
      "organizationCode": "15a59878e82b4f3c8b29dc4a56372ba9",
      "organizationType": "COMPANY",
      "parentCode": "ffae5adaa1e94c27b2bba90bb2350c02",
      "parentName": "上级组织名称",
      "parentOrgNo": "SHANGJIZHANGHAO"
    }
  ],
  "message": "成功"
}
```

------

## 2. 查询用户的企业授权印章列表

**接口**：`/seals/v1/sealcontrols/organizationSeals/list`
 **说明**：入参是组织编码，查出印章 id 及用印人编码。

### 功能描述

根据印章形态 / 机构 code / 印章名称 / 用户 code 查询用户的企业授权印章信息，包括：印章名称、印章所属机构、印章图片等信息。
 根据机构 code 可查询指定机构的企业印章信息，包括：印章名称、印章所属机构、印章图片等信息。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/seals/v1/sealcontrols/organizationSeals/list`
- 请求方法：`POST`

### 请求参数

| 参数名称         | 参数类型 | 必选 | 参数位置 | 参数说明                                                     |
| ---------------- | -------- | ---- | -------- | ------------------------------------------------------------ |
| sealId           | string   | 否   | body     | 印章 id，精确查询                                            |
| sealPattern      | string   | 是   | body     | 印章形态：`1`-商密印章（原电子章）、`3`-国密印章、`4`-UKey商密印章、`5`-UKey国密印章、`2`-物理印章。查询含有某一印章形态的印章，一次只能传 1 个值 |
| organizationCode | string   | 否   | body     | 组织编码。`organizationCode` 和 `customOrgNo` 都没有值则展示所有机构的印章信息；两者都有值，以 `organizationCode` 为准 |
| customOrgNo      | string   | 否   | body     | 组织账号。`organizationCode` 和 `customOrgNo` 都没有值则展示所有机构的印章信息；两者都有值，以 `organizationCode` 为准 |
| sealTypeCode     | string   | 否   | body     | 印章类型编码。不传则展示所有印章类型；传值则查询指定印章类型：公章 `COMMON-SEAL`、法人章 `LEGAL-PERSON-SEAL`、自定义印章类型使用“查询企业印章类型”接口返回的 `sealTypeCode` |
| sealName         | string   | 否   | body     | 印章名称（模糊匹配）                                         |
| userCode         | string   | 否   | body     | 用户编码。`userCode` 与 `customAccountNo` 都有值时以 `userCode` 为准。用于电子印章授权用户 code 或物理印章绑定用户 code |
| customAccountNo  | string   | 否   | body     | 用户账号。`userCode` 与 `customAccountNo` 都有值时以 `userCode` 为准。用于电子印章授权用户账号或物理印章绑定用户账号 |
| keySNList        | array    | 否   | body     | UKey 序列号列表                                              |
| pageSize         | int      | 是   | body     | 单页数量，不超过 50 条                                       |
| pageNo           | int      | 是   | body     | 当前页，为正整数                                             |

### 响应参数

| 参数名称 | 字段类型 | 说明                               |
| -------- | -------- | ---------------------------------- |
| code     | int      | 业务码，200 表示成功，其他表示失败 |
| message  | string   | 描述信息                           |
| data     | object   | 业务信息                           |

### 请求示例

```
{
  "customAccountNo": "",
  "customOrgNo": "",
  "keySNList": [],
  "organizationCode": "",
  "pageNo": 0,
  "pageSize": 0,
  "sealId": "",
  "sealName": "",
  "sealPattern": "",
  "sealTypeCode": "",
  "userCode": ""
}
```

### 响应示例

```
{
  "code": 0,
  "data": {
    "records": [
      {
        "asn1SealInfo": "",
        "authorizationScope": 0,
        "base64img": "",
        "defaultSeal": "",
        "downloadUrl": "",
        "keySN": "",
        "organizationCode": "",
        "organizationName": "",
        "sealCode": "",
        "sealColour": "",
        "sealExplain": "",
        "sealHeight": 0,
        "sealId": "",
        "sealName": "",
        "sealPattern": "",
        "sealSN": "",
        "sealSource": "",
        "sealStatus": "",
        "sealStructure": "",
        "sealTypeCode": "",
        "sealTypeName": "",
        "sealWidth": 0,
        "sealsignersInfos": [
          {
            "customAccountNo": "",
            "customDepartmentNo": "",
            "customOrgNo": "",
            "departmentCode": "",
            "organizationCode": "",
            "userCode": ""
          }
        ],
        "unionSealCode": "",
        "unionSealId": ""
      }
    ],
    "total": 0
  },
  "message": ""
}
```

------

## 3. 查询外部用户详情

**接口**：`/manage/v1/outerUsers/detail`

### 功能描述

根据账号 / 姓名 / 手机号 / 证件号等多个条件组合查询外部用户。根据姓名模糊查询到的结果可能有多条用户记录，则返回匹配的用户列表，按创建时间倒序排序；查询条件不能全为空。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/manage/v1/outerUsers/detail`
- 请求方法：`POST`

### 请求参数

| 参数名称        | 参数类型 | 必选 | 参数位置 | 参数说明                                                     |
| --------------- | -------- | ---- | -------- | ------------------------------------------------------------ |
| userCode        | string   | 否   | body     | 用户编码（本系统的唯一标识）。如果 `userCode`、`customAccountNo` 两者都有值，以 `userCode` 为准 |
| customAccountNo | string   | 否   | body     | 用户账号（客户系统的唯一标识）。如果 `userCode`、`customAccountNo` 两者都有值，以 `userCode` 为准 |
| name            | string   | 否   | body     | 用户姓名，支持模糊查询                                       |
| mobile          | string   | 否   | body     | 手机号                                                       |
| email           | string   | 否   | body     | 邮箱                                                         |
| licenseNo       | string   | 否   | body     | 证件号码                                                     |

### 响应参数

| 参数名称 | 参数类型 | 参数说明                           |
| -------- | -------- | ---------------------------------- |
| code     | int      | 业务码，200 表示成功，其他表示失败 |
| message  | string   | 描述信息                           |
| data     | object   | 业务信息                           |

### 请求示例

```
{
  "customAccountNo": "zhangs",
  "licenseNo": 372522111111111111,
  "mobile": 18611111111,
  "name": "张三",
  "userCode": "6fff7aac9be14399a9bc3ff214127d48"
}
```

### 响应示例

```
{
  "code": 200,
  "message": "服务器成功返回",
  "data": [
    {
      "userCode": "tiant111",
      "customAccountNo": "tiant111",
      "name": "甜甜",
      "email": "tiantian@111.com",
      "mobile": "14211111111",
      "licenseType": "ID_CARD",
      "licenseNo": "",
      "bankCardNo": "",
      "otherOrganization": [
        {
          "otherOrganizationCode": "fd0b71693ca84bbaaa6ff114d3a7b63d",
          "otherCustomOrgNo": "esignTest014"
        },
        {
          "otherOrganizationCode": "e98b9d3480864043b5c61bf5853eb99a",
          "otherCustomOrgNo": "esignTest013"
        }
      ],
      "mainCustomOrgNo": "esignTest015",
      "mainOrganizationCode": "58827c8828bb4d87a202aa6e561090ba"
    }
  ]
}
```

------

## 4. 新建外部用户

**接口**：`/manage/v1/outerUsers/create`

### 功能描述

以下 2 类用户可以维护为外部用户：

1. 外部组织的成员，新建此类外部用户时需填写所属的外部组织。
2. 和本企业签署合同的个人相对方也建议维护为外部用户。

支持批量新建外部用户。创建成功后接口将返回天印系统的用户编码 `userCode`，作为本系统用户的唯一标识，与客户系统传入的账号 `customAccountNo` 一一对应。
 返回的 `userCode` 请注意妥善保存，以便用于后续印控、文档、签署业务。
 批量新建用户数量上限：50 个。
 新建用户的证件号重复时，当证件号、证件类型、姓名与已有账号都相同则返回已有账号；没有证件号时，手机号、姓名与已有账号相同则返回已有账号。
 已注销人员不需要同步至本系统。
 外部用户属于【个人相对方】时，默认组织 `mainOrganizationCode` 应设置为空、`mainCustomOrgNo` 应设置为空，其他组织也应设置为空。
 外部用户属于【企业成员】时默认组织 `mainOrganizationCode` 传具体的外部企业，或 `mainCustomOrgNo` 传具体的外部企业。
 以下字段的长度支持在系统参数-组织用户分组中配置：姓名、账号、证件号码、银行卡号、邮箱。
 新建外部用户的【项目来源】字段自动读取请求头中的 `projectid`。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/manage/v1/outerUsers/create`
- 请求方法：`POST`

### 请求参数

| 参数名称                          | 参数类型 | 必选 | 参数位置 | 参数说明                             |
| --------------------------------- | -------- | ---- | -------- | ------------------------------------ |
| apiBatchSaveOutsideUserRequestVos | array    | 是   | body     | 新建外部用户信息列表，批量上限 50 个 |

### 响应参数

| 参数名称 | 参数类型 | 参数说明                           |
| -------- | -------- | ---------------------------------- |
| code     | int      | 业务码，200 表示成功，其他表示失败 |
| message  | string   | 描述信息                           |
| data     | object   | 业务信息                           |

### 请求示例

#### 新建外部组织成员

```
[
  {
    "customAccountNo": "tanjj01",
    "name": "谭晶晶",
    "mobile": "12548485471",
    "email": "asdfasdfssdf@asfsdfsdf.asdfsadf",
    "licenseNo": "1235469879545454",
    "licenseType": "PASSPORT",
    "bankCardNo": "",
    "mainOrganizationCode": "",
    "mainCustomOrgNo": "HZTGQY",
    "otherOrganization": [
      {
        "otherOrganizationCode": "",
        "otherCustomOrgNo": "JKCSZZTEST"
      },
      {
        "otherOrganizationCode": "",
        "otherCustomOrgNo": "AAAABBBBTEST"
      }
    ]
  }
]
```

#### 新建个人相对方

```
[
  {
    "customAccountNo": "tanjj01",
    "name": "谭晶晶",
    "mobile": "12548485471",
    "email": "asdfasdfssdf@asfsdfsdf.asdfsadf",
    "licenseNo": "1235469879545454",
    "licenseType": "PASSPORT",
    "bankCardNo": ""
  }
]
```

### 响应示例

```
{
  "code": 200,
  "data": {
    "failureCount": 1,
    "failureData": [
      {
        "code": "1123456",
        "customAccountNo": "zhangs",
        "existCustomAccountNo": "",
        "existUserCode": "",
        "message": "手机号码不正确"
      }
    ],
    "successCount": 1,
    "successData": [
      {
        "customAccountNo": "zhangs",
        "userCode": "6fff7aac9be14399a9bc3ff214127d48"
      }
    ]
  },
  "message": "成功"
}
```

------

## 5. 修改外部用户

**接口**：`/manage/v1/outerUsers/update`

### 功能描述

当用户的信息发生变更时，可以根据用户编码或用户账号定位到唯一的一条外部用户数据，修改外部用户信息。

允许对活跃用户进行修改，已注销、已删除账号不允许修改。
 更新用户的姓名、证件类型与证件号码、银行卡号、手机号，会重置用户实名状态为未实名。
 对于 string 类型，传 `null` 或不传表示不更新，传空字符串表示该字段内容进行清空；目前允许清空的字段是手机号、邮箱、证件号码、其他组织，但手机号、邮箱不能同时为空。
 更新其他组织，需要传入用户修改后的所有其他组织列表。
 外部用户属于【个人相对方】时，默认组织 `mainOrganizationCode` 应设置为空、`mainCustomOrgNo` 应设置为空，其他组织也应设置为空。
 外部用户属于【企业成员】时默认组织 `mainOrganizationCode` 传具体的外部企业，或 `mainCustomOrgNo` 传具体的外部企业。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/manage/v1/outerUsers/update`
- 请求方法：`POST`

### 请求参数

| 参数名称             | 参数类型 | 必选 | 参数位置 | 参数说明                                                     |
| -------------------- | -------- | ---- | -------- | ------------------------------------------------------------ |
| userCode             | string   | 否   | body     | 用户编码（本系统的唯一标识，用于查询）。`userCode`、`customAccountNo` 必填其一，如果两者都有值，以 `userCode` 为准 |
| customAccountNo      | string   | 否   | body     | 用户账号（客户系统的唯一标识，用于查询）。`userCode`、`customAccountNo` 必填其一，如果两者都有值，以 `userCode` 为准 |
| name                 | string   | 否   | body     | 姓名                                                         |
| mobile               | string   | 否   | body     | 手机号。`null` 表示不更新，`""` 表示清空                     |
| email                | string   | 否   | body     | 邮箱。`null` 表示不更新，`""` 表示清空                       |
| licenseType          | string   | 否   | body     | 证件类型，默认 `ID_CARD`。可选：`ID_CARD`、`HK_MACAO`、`TAIWAN`、`PASSPORT`、`OTHER` |
| licenseNo            | string   | 否   | body     | 证件号码。`null` 表示不更新，`""` 表示清空                   |
| bankCardNo           | string   | 否   | body     | 银行卡号                                                     |
| mainOrganizationCode | string   | 否   | body     | 默认组织编码。个人相对方时应为空；外部组织成员时可传具体外部企业。若与 `mainCustomOrgNo` 都有值，以 `mainOrganizationCode` 为准 |
| mainCustomOrgNo      | string   | 否   | body     | 默认组织账号。个人相对方时应为空；外部组织成员时可传具体外部企业。若与 `mainOrganizationCode` 都有值，以 `mainOrganizationCode` 为准 |
| otherOrganization    | array    | 否   | body     | 其他组织账号。个人相对方没有其他组织；外部组织成员允许有多个。`[]` 或 `null` 表示清空 |

### 响应参数

| 参数名称 | 参数类型 | 参数说明                           |
| -------- | -------- | ---------------------------------- |
| code     | int      | 业务码，200 表示成功，其他表示失败 |
| message  | string   | 描述信息                           |
| data     | object   | 业务信息                           |

### 请求示例

#### 修改外部组织成员

```
{
  "bankCardNo": 6212262201023557228,
  "customAccountNo": "zhangs",
  "email": "17645269889@163.com",
  "licenseNo": 371521198710123153,
  "licenseType": "ID_CARD",
  "mainCustomOrgNo": "HZTGXXKJYXGS",
  "mainOrganizationCode": "",
  "mobile": 17645269889,
  "name": "张三",
  "otherOrganization": [
    {
      "otherCustomOrgNo": "YYKJ ",
      "otherOrganizationCode": ""
    },
    {
      "otherCustomOrgNo": " CSZZ",
      "otherOrganizationCode": ""
    }
  ],
  "userCode": "611f36badf494bf6838ec5618fe570b7"
}
```

#### 修改个人相对方

```
{
  "bankCardNo": 6212262201023557228,
  "customAccountNo": "zhangs",
  "email": "17645269889@163.com",
  "licenseNo": 371521198710123153,
  "licenseType": "ID_CARD",
  "mobile": 17645269889,
  "name": "张三",
  "userCode": "611f36badf494bf6838ec5618fe570b7"
}
```

### 响应示例

```
{
  "code": 200,
  "data": {
    "customAccountNo": "zhangs",
    "userCode": "6fff7aac9be14399a9bc3ff214127d48"
  },
  "message": "成功"
}
```

------

## 6. 文件与签署相关接口

### 6.1 生成上传文件链接

**接口**：`/file/v1/generateUploadUrl`

### 6.2 上传文件到指定链接

**接口**：`/file/v1/pdf/uploadAndSpiltV2`

### 6.3 使用文件发起签署（一步发起签署）

**接口**：`/esign-signs/v1/signFlow/createAndStart`

**说明**：这个已经有了，会返回签署链接。

------

## 7. 获取 AccessToken

**接口**：`/etl-integrate/v1/client/getAccessToken`

### 功能描述

第三方获取 AccessToken，传入天印项目项目 id、项目秘钥，返回 `accessToken`。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/etl-integrate/v1/client/getAccessToken`
- 请求方法：`POST`

### 请求参数

| 参数名称         | 字段类型 | 必选 | 参数位置 | 参数说明         |
| ---------------- | -------- | ---- | -------- | ---------------- |
| getAccessTokenVo | object   | 是   | body     | getAccessTokenVo |

### 响应参数

| 参数名称 | 参数类型 | 参数说明                                |
| -------- | -------- | --------------------------------------- |
| success  | string   | 成功失败标志，`true`-成功，`false`-失败 |
| status   | int      | 状态标记                                |
| message  | string   | 描述信息                                |
| data     | object   | 业务信息                                |

### 请求示例

```
{
  "clientId": "1000019",
  "clientSecret": "4Ju9*******7LUI3"
}
```

### 响应示例

```
{
  "success": true,
  "status": 200,
  "message": "服务器成功返回",
  "data": {
    "accessToken": "1cb3e9***********0231fcdcec2"
  }
}
```

------

## 8. 获取 ssoToken

**接口**：`/etl-integrate/v1/client/getSsoToken`

### 功能描述

传入登录用户账号、重定向地址（天印 V6 页面地址）等信息，获取可以免登访问重定向地址的链接 `ssoRedirectUrl`。

### 接口地址与请求方法

- 接口地址：`http(s)://{host}/etl-integrate/v1/client/getSsoToken`
- 请求方法：`POST`

### 请求参数

| 参数名称      | 字段类型 | 必选 | 参数位置 | 参数说明      |
| ------------- | -------- | ---- | -------- | ------------- |
| getSsoTokenVo | object   | 是   | body     | getSsoTokenVo |

### 响应参数

| 参数名称 | 参数类型 | 参数说明                                |
| -------- | -------- | --------------------------------------- |
| success  | string   | 成功失败标志，`true`-成功，`false`-失败 |
| status   | int      | 状态标记                                |
| message  | string   | 描述信息                                |
| data     | object   | 业务信息                                |

### 请求示例

```
{
  "accessToken": "43aa4c1**************42cc7384486",
  "clientId": "1000013",
  "domain": "admin_platform",
  "loginAccount": "b3ZAzStefIOnaCoe799e9Q==",
  "redirectUrl": "http://xxx.xxx.xxx/ec-manage-web/orguser/outsideorganisation"
}
```

### 响应示例

```
{
  "success": true,
  "status": 200,
  "message": "服务器成功返回",
  "data": {
    "ssoToken": "eyJhbGciOiJ*****************************vZz9d7QZlFAd0",
    "ssoCode": "YDFjtADXDE************QoMb",
    "ssoSuffix": "tCode=269a8b2********6b34b91bdf",
    "ssoRedirectUrl": "http://xxx.xxx.xxx/ec-manage-web/orguser/outsideorganisation?tCode=269a8b23b8e64d0fa1c60e6b34b91bdf"
  }
}
```

------

## 9. 打开签署页，签署

打开签署页后进行签署，会有一个回调。

------

## 10. 文件删除

**接口**：`/esign-docs/v1/cus/file/delete`

**说明**：流程整体签署完成后再删除。