# 电子签接口联调说明（基于接口文档与 Java Test 示例整理）

## 1. 目标
实现一个 Java Maven 项目，用于验证电子签接口调用，重点覆盖：

1. 普通 GET 请求签名调用
2. 普通 POST JSON 请求签名调用
3. 文件上传签名调用

---

## 2. 基础信息

### 请求协议
- HTTP / HTTPS
- UTF-8
- JSON 接口默认使用 `application/json; charset=UTF-8`

### 通用请求头
所有请求必须带：

```http
X-timevale-project-id: <projectId>
X-timevale-signature: <signature>
Accept: */*
Content-Type: application/json; charset=UTF-8
```

其中：

- `projectId`：项目 ID
- `signature`：签名结果

## 3. 签名规则

### 3.1 非 IP 白名单用户签名规则

- `GET / DELETE`：签名明文 = URL 中 `?` 后面的 query string
- `POST / PUT`：签名明文 = request body 原始 JSON 字符串
- 签名算法：`HMAC_SHA_256`
- 密钥：`projectSecret`
- 输出格式：十六进制字符串（hex）

### 3.2 Java 示例签名代码

```
public static String sign(String content, String key) {
    byte[] bytes = new HmacUtils(HmacAlgorithms.HMAC_SHA_256, key).hmac(content);
    return new String(Hex.encodeHex(bytes));
}
```

------

## 4. GET 请求签名示例

### 示例接口

```
GET /esign-signs/v1/signFlow/signUrls?signFlowId=24210df8420968c1e785a3b7582295b6
```

### Java 示例逻辑

```
String getSignFlowApi =
    "/esign-signs/v1/signFlow/signUrls?signFlowId=" + "24210df8420968c1e785a3b7582295b6";

int index = getSignFlowApi.indexOf("?");
String plaintext = index == -1 ? "" : getSignFlowApi.substring(index + 1);
String reqSignature = sign(plaintext, secret);
```

### 说明

- GET 的签名明文只取 query string
- 不包含域名
- 不包含 path
- 不包含 `?`

例如签名明文应为：

```
signFlowId=24210df8420968c1e785a3b7582295b6
```

------

## 5. POST 请求签名示例

### 示例接口

```
POST /manage/v1/innerOrganizations/detail
```

### Java 示例逻辑

```
JSONObject reqBodyObj = new JSONObject(true);
reqBodyObj.put("organizationCode", "");
reqBodyObj.put("customOrgNo", "");
reqBodyObj.put("name", "杭州天谷");

String reqBodyData = reqBodyObj.toString();
String plaintext = reqBodyData;
String reqSignature = sign(plaintext, secret);
```

### 说明

- POST 的签名明文 = body 原始 JSON 字符串
- 不能改字段顺序
- 不能随意格式化 JSON 后再签名
- 发请求时 body 与签名时使用的 JSON 字符串必须保持一致

------

## 6. 文件上传请求签名示例

### 示例接口

```
POST /file/v1/pdf/uploadAndSpilt
```

### Java 示例逻辑

```
JSONObject reqBodyObj = new JSONObject(true);
reqBodyObj.put("file", "测试文件密码123456.pdf");
reqBodyObj.put("filePwd", "123456");

String reqBodyData = reqBodyObj.toString();
String plaintext = reqBodyData;
String reqSignature = sign(plaintext, secret);
String filePath = "/xxx/xxx/测试文件密码123456.pdf";
String fileFieldName = "file";

String result = HTTPHelper.uploadFile(
    uploadApiUrl,
    fileFieldName,
    filePath,
    reqBodyObj,
    header,
    "UTF-8"
);
```

### 说明

- 文件字段名：`file`
- 支持额外字段：`filePwd`
- 上传请求也需要签名
- 签名明文仍然基于 JSON body，而不是文件二进制内容

------

## 7. 推荐优先实现的接口

### 7.1 获取签署地址

```
GET /esign-signs/v1/signFlow/signUrls?signFlowId=xxx
```

用途：

- 验证 GET 签名是否正确
- 获取签署链接

------

### 7.2 普通 POST 示例接口

```
POST /manage/v1/innerOrganizations/detail
```

用途：

- 验证 POST JSON 签名是否正确

------

### 7.3 文件上传接口

```
POST /file/v1/pdf/uploadAndSpilt
```

用途：

- 验证文件上传签名是否正确

------

## 8. 返回结构

接口返回通常为：

```
{
  "code": 200,
  "message": "成功",
  "data": {}
}
```

处理要求：

- `code == 200`：认为成功
- `code != 200`：抛出异常，并打印完整响应

------

## 9. 实现要求

请实现一个 Java Maven 项目，要求如下：

### 9.1 配置项

抽成配置：

- `host`
- `projectId`
- `projectSecret`

例如支持：

- `application.properties`
- 或 `.env`
- 或常量类

### 9.2 核心能力

实现一个 `EsignClient`，至少包含：

- `String sign(String content, String secret)`
- `String doGet(String pathWithQuery)`
- `String doPost(String path, JSONObject body)`
- `String uploadFile(String path, File file, JSONObject extraBody)`

### 9.3 通用要求

- 自动添加签名头
- 打印请求 URL、请求头、请求体、响应体
- 遇到 `code != 200` 抛出运行时异常
- 保留清晰的日志，便于联调

### 9.4 推荐技术栈

- Java 8+
- Maven
- HTTP 客户端可选：
  - `OkHttp`
  - 或 `HttpURLConnection`
- JSON 可选：
  - `fastjson`
  - 或 `Jackson`

------

## 10. 测试入口要求

请提供一个 `main` 方法或测试类，例如 `EsignTest`，演示以下流程：

1. 调用 GET 接口：获取签署地址
2. 调用 POST 接口：发送普通 JSON 请求
3. 调用上传接口：上传一个 PDF 文件
4. 打印每一步请求与响应
5. 失败时打印错误详情

------

## 11. 注意事项

1. GET 签名只签 query string
2. POST 签名只签 JSON 原文
3. JSON 字段顺序要稳定，建议保持和构造时一致
4. 上传文件时签名不是签文件本身，而是签附带的 JSON body
5. 请求头名称按文档示例使用，不要擅自修改