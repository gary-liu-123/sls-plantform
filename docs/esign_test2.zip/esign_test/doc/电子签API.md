# 电子签 API 接口文档

## 基础信息

### 环境配置

```
Host: https://esign-test.seres.cn
ProjectId: 1000007
ProjectSecret: 7l3cIaTfR4LiKwzQ
```

### 签名机制

所有接口请求需在请求头中携带以下签名信息：

| 请求头 | 说明 |
|--------|------|
| X-timevale-project-id | 项目 ID |
| X-timevale-signature | HMAC-SHA256 签名值（小写十六进制） |
| Content-Type | application/json; charset=UTF-8 |

**签名规则：**

- **POST 请求**：签名明文 = 请求体 JSON 字符串
- **GET 请求**：签名明文 = Query String（不含 `?`）
- **文件上传**：签名明文 = extraBody 的 JSON 原文

```java
// HMAC-SHA256 签名示例
HmacUtils(HMAC_SHA_256, projectSecret).hmac(plaintext)
// 结果转小写十六进制字符串
```

### 统一响应格式

```json
{
  "code": 0,
  "message": "成功",
  "data": {}
}
```

---

## 1. 查询内部组织详情

**接口地址**：`POST /manage/v1/innerOrganizations/detail`

**功能描述**：根据统一社会信用代码查询内部组织信息，获取组织编码。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| licenseNo | string | 否 | 统一社会信用代码 |
| licenseType | string | 否 | 证件类型，默认 `CREDIT_CODE` |
| organizationCode | string | 否 | 组织编码（本系统唯一标识） |
| customOrgNo | string | 否 | 组织账号（客户系统唯一标识） |
| name | string | 否 | 组织名称，支持模糊查询 |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data | array | 组织列表 |
| data[].organizationCode | string | 组织编码 |
| data[].name | string | 组织名称 |
| data[].licenseNo | string | 证件号 |
| data[].legalRepName | string | 法定代表人姓名 |

### 请求示例

```json
{
  "licenseNo": "915001066608898456",
  "licenseType": "CREDIT_CODE"
}
```

### 响应示例

```json
{
  "code": 200,
  "message": "成功",
  "data": [
    {
      "organizationCode": "15a59878e82b4f3c8b29dc4a56372ba9",
      "name": "赛力斯集团",
      "licenseNo": "915001066608898456",
      "licenseType": "CREDIT_CODE",
      "legalRepName": "张三"
    }
  ]
}
```

---

## 2. 查询企业授权印章列表

**接口地址**：`POST /seals/v1/sealcontrols/organizationSeals/list`

**功能描述**：查询企业的印章信息，包括印章ID和授权用印人。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| organizationCode | string | 否 | 组织编码 |
| sealPattern | string | 是 | 印章形态：`1`-商密印章、`3`-国密印章 |
| sealTypeCode | string | 否 | 印章类型：`COMMON-SEAL`-公章、`LEGAL-PERSON-SEAL`-法人章 |
| pageNo | int | 是 | 当前页码 |
| pageSize | int | 是 | 单页数量（最大50） |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.records | array | 印章记录列表 |
| data.records[].sealId | string | 印章ID |
| data.records[].sealName | string | 印章名称 |
| data.records[].sealsignersInfos | array | 授权用印人列表 |
| data.records[].sealsignersInfos[].userCode | string | 用印人编码 |

### 请求示例

```json
{
  "organizationCode": "15a59878e82b4f3c8b29dc4a56372ba9",
  "sealPattern": "1",
  "sealTypeCode": "COMMON-SEAL",
  "pageNo": 1,
  "pageSize": 10
}
```

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "records": [
      {
        "sealId": "a1b2c3d4e5f6g7h8i9j0",
        "sealName": "赛力斯集团公章",
        "sealTypeCode": "COMMON-SEAL",
        "sealPattern": "1",
        "sealsignersInfos": [
          {
            "userCode": "u1a2b3c4d5e6f7g8h9i0j0"
          }
        ]
      }
    ],
    "total": 1
  }
}
```

---

## 3. 查询外部用户详情

**接口地址**：`POST /manage/v1/outerUsers/detail`

**功能描述**：根据手机号、姓名等条件查询外部用户信息。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| userCode | string | 否 | 用户编码（本系统唯一标识） |
| customAccountNo | string | 否 | 用户账号（客户系统唯一标识） |
| name | string | 否 | 用户姓名，支持模糊查询 |
| mobile | string | 否 | 手机号 |
| email | string | 否 | 邮箱 |
| licenseNo | string | 否 | 证件号码 |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data | array | 用户列表 |
| data[].userCode | string | 用户编码 |
| data[].customAccountNo | string | 用户账号 |
| data[].name | string | 姓名 |
| data[].mobile | string | 手机号 |
| data[].licenseNo | string | 证件号 |
| data[].licenseType | string | 证件类型 |

### 请求示例

```json
{
  "mobile": "18685095797",
  "name": "苏枕雪"
}
```

### 响应示例

```json
{
  "code": 200,
  "message": "成功",
  "data": [
    {
      "userCode": "6fff7aac9be14399a9bc3ff214127d48",
      "customAccountNo": "suzhenxue_test",
      "name": "苏枕雪",
      "mobile": "18685095797",
      "licenseNo": "110105200010018706",
      "licenseType": "ID_CARD"
    }
  ]
}
```

---

## 4. 新建外部用户

**接口地址**：`POST /manage/v1/outerUsers/create`

**功能描述**：批量创建外部用户，返回系统用户编码。

### 请求参数

**请求体为 JSON 数组格式：**

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| customAccountNo | string | 是 | 客户系统账号（唯一标识） |
| name | string | 是 | 姓名 |
| mobile | string | 是 | 手机号 |
| email | string | 否 | 邮箱 |
| licenseNo | string | 否 | 证件号码 |
| licenseType | string | 否 | 证件类型：`ID_CARD`-身份证、`PASSPORT`-护照等 |
| bankCardNo | string | 否 | 银行卡号 |
| mainOrganizationCode | string | 否 | 默认组织编码（个人相对方为空） |
| mainCustomOrgNo | string | 否 | 默认组织账号（个人相对方为空） |
| otherOrganization | array | 否 | 其他组织列表 |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.successCount | int | 成功创建数量 |
| data.successData | array | 成功数据 |
| data.successData[].userCode | string | 用户编码 |
| data.successData[].customAccountNo | string | 用户账号 |
| data.failureCount | int | 失败数量 |
| data.failureData | array | 失败数据 |

### 请求示例（个人相对方）

```json
[
  {
    "customAccountNo": "suzhenxue_test",
    "name": "苏枕雪",
    "mobile": "18685095797",
    "licenseNo": "110105200010018706",
    "licenseType": "ID_CARD"
  }
]
```

### 响应示例

```json
{
  "code": 200,
  "message": "成功",
  "data": {
    "successCount": 1,
    "successData": [
      {
        "userCode": "6fff7aac9be14399a9bc3ff214127d48",
        "customAccountNo": "suzhenxue_test"
      }
    ],
    "failureCount": 0,
    "failureData": []
  }
}
```

---

## 5. 修改外部用户

**接口地址**：`POST /manage/v1/outerUsers/update`

**功能描述**：根据用户编码或账号修改外部用户信息。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| userCode | string | 条件必填 | 用户编码（与 customAccountNo 二选一） |
| customAccountNo | string | 条件必填 | 用户账号（与 userCode 二选一） |
| name | string | 否 | 姓名 |
| mobile | string | 否 | 手机号（`null`不更新，`""`清空） |
| email | string | 否 | 邮箱 |
| licenseType | string | 否 | 证件类型 |
| licenseNo | string | 否 | 证件号码 |
| bankCardNo | string | 否 | 银行卡号 |
| mainOrganizationCode | string | 否 | 默认组织编码 |
| mainCustomOrgNo | string | 否 | 默认组织账号 |
| otherOrganization | array | 否 | 其他组织列表 |

### 请求示例

```json
{
  "userCode": "6fff7aac9be14399a9bc3ff214127d48",
  "name": "苏枕雪",
  "mobile": "18685095797",
  "licenseNo": "110105200010018706",
  "licenseType": "ID_CARD"
}
```

### 响应示例

```json
{
  "code": 200,
  "message": "成功",
  "data": {
    "userCode": "6fff7aac9be14399a9bc3ff214127d48",
    "customAccountNo": "suzhenxue_test"
  }
}
```

---

## 6. 文件与签署流程

### 6.1 生成上传文件链接

**接口地址**：`POST /file/v1/generateUploadUrl`

**功能描述**：获取文件上传的临时链接。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| requestID | string | 是 | 请求唯一标识（建议使用UUID，去除`-`并大写） |
| type | int | 是 | 文件类型：`0`-普通文件 |
| expire | int | 是 | 链接有效期（秒），建议 `300` |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.url | string | 上传地址（需替换内网IP为域名） |

### 请求示例

```json
{
  "requestID": "A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6",
  "type": 0,
  "expire": 300
}
```

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "url": "http://10.0.0.1/file/v1/pdf/uploadAndSpiltV2?..."
  }
}
```

---

### 6.2 上传文件

**接口地址**：`POST {uploadUrl}`

**功能描述**：使用获取的上传链接上传PDF文件。

### 请求参数（multipart/form-data）

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| file | File | 是 | PDF文件 |
| file | string | 是 | 文件名（作为表单字段） |

**请求头：**
```
X-timevale-project-id: {ProjectId}
X-timevale-signature: {signature}  // 签名明文 = extraBody 的 JSON
Accept: */*
Content-Type: multipart/form-data
```

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.fileKey | string | 文件唯一标识 |

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "fileKey": "f1k2e3y4A5B6C7D8E9F0G1H2I3J4K5L6M7N8O9P0"
  }
}
```

---

### 6.3 发起签署流程（一步发起）

**接口地址**：`POST /esign-signs/v1/signFlow/createAndStart`

**功能描述**：使用已上传的文件发起签署流程，直接返回签署链接。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| subject | string | 是 | 流程主题 |
| businessNo | string | 是 | 业务编号（客户系统唯一） |
| businessTypeCode | string | 是 | 业务类型编码 |
| initiatorInfo | object | 是 | 发起方信息 |
| initiatorInfo.organizationCode | string | 是 | 发起方组织编码 |
| initiatorInfo.userCode | string | 是 | 发起方用户编码（用印人） |
| initiatorInfo.userType | int | 是 | 用户类型：`1`-发起方 |
| signFiles | array | 是 | 签署文件列表 |
| signFiles[].fileKey | string | 是 | 文件Key |
| signFiles[].fileOrder | int | 是 | 文件序号 |
| signerInfos | array | 是 | 签署方列表 |
| signerInfos[].userCode | string | 是 | 签署人编码 |
| signerInfos[].customAccountNo | string | 否 | 客户系统账号 |
| signerInfos[].userType | int | 是 | 用户类型：`2`-相对方 |
| signerInfos[].signNode | int | 是 | 签署节点，最小为 `1` |
| signerInfos[].signOrder | int | 是 | 签署顺序 |
| signerInfos[].autoSign | int | 是 | 自动签署：`0`-否 |
| signerInfos[].signMode | int | 是 | 签署模式：`0`-顺序签 |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.signFlowId | string | 签署流程ID |
| data.signUrlInfos | array | 签署链接列表 |
| data.signUrlInfos[].signUrl | string | 签署链接 |

### 请求示例

```json
{
  "subject": "劳动合同签署-苏枕雪",
  "businessNo": "hr_1736284800000",
  "businessTypeCode": "d57044ecc471e12387838d1f5bbd78cf",
  "initiatorInfo": {
    "organizationCode": "15a59878e82b4f3c8b29dc4a56372ba9",
    "userCode": "u1a2b3c4d5e6f7g8h9i0j0",
    "userType": 1
  },
  "signFiles": [
    {
      "fileKey": "f1k2e3y4A5B6C7D8E9F0G1H2I3J4K5L6M7N8O9P0",
      "fileOrder": 1
    }
  ],
  "signerInfos": [
    {
      "userCode": "6fff7aac9be14399a9bc3ff214127d48",
      "customAccountNo": "suzhenxue_test",
      "userType": 2,
      "signNode": 1,
      "signOrder": 1,
      "autoSign": 0,
      "signMode": 0
    }
  ]
}
```

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "signFlowId": "s1f2l3o4w5I6d7A8B9C0D1E2F3G4H5I6J7K8L9M0N",
    "signUrlInfos": [
      {
        "signUrl": "http://10.0.0.1/esign-signs/h5/sign?signFlowId=...&from=...&auth=...",
        "userCode": "6fff7aac9be14399a9bc3ff214127d48"
      }
    ]
  }
}
```

---

## 7. 获取签署链接

**接口地址**：`GET /esign-signs/v1/signFlow/signUrls`

**功能描述**：根据签署流程ID获取签署链接（若发起时未返回）。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| signFlowId | string | 是 | 签署流程ID |

### 响应参数

| 参数名称 | 参数类型 | 说明 |
|----------|----------|------|
| data.signUrlInfos | array | 签署链接列表 |
| data.signUrlInfos[].signUrl | string | 签署链接 |
| data.signUrlInfos[].userCode | string | 用户编码 |

### 请求示例

```
GET /esign-signs/v1/signFlow/signUrls?signFlowId=s1f2l3o4w5I6d7A8B9C0D1E2F3G4H5I6J7K8L9M0N
```

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "signUrlInfos": [
      {
        "signUrl": "https://esign-test.seres.cn/esign-signs/h5/sign?signFlowId=...&from=...&auth=...",
        "userCode": "6fff7aac9be14399a9bc3ff214127d48"
      }
    ]
  }
}
```

---

## 8. 删除文件

**接口地址**：`POST /esign-docs/v1/cus/file/delete`

**功能描述**：删除已上传的文件（建议签署完成后调用）。

### 请求参数

| 参数名称 | 参数类型 | 必选 | 说明 |
|----------|----------|------|------|
| fileKey | string | 是 | 文件Key |

### 请求示例

```json
{
  "fileKey": "f1k2e3y4A5B6C7D8E9F0G1H2I3J4K5L6M7N8O9P0"
}
```

### 响应示例

```json
{
  "code": 0,
  "message": "成功",
  "data": true
}
```

---

## 完整流程示例

```java
// 1. 查询组织
POST /manage/v1/innerOrganizations/detail
{"licenseNo": "915001066608898456", "licenseType": "CREDIT_CODE"}
→ organizationCode

// 2. 查询印章
POST /seals/v1/sealcontrols/organizationSeals/list
{"organizationCode": "...", "sealPattern": "1", "sealTypeCode": "COMMON-SEAL", "pageNo": 1, "pageSize": 10}
→ sealId, sealUserCode

// 3. 查询外部用户
POST /manage/v1/outerUsers/detail
{"mobile": "18685095797", "name": "苏枕雪"}

// 4. 若用户不存在，创建
POST /manage/v1/outerUsers/create
[{"customAccountNo": "suzhenxue_test", "name": "苏枕雪", "mobile": "18685095797", "licenseNo": "110105200010018706", "licenseType": "ID_CARD"}]
→ userCode

// 5. 生成上传链接
POST /file/v1/generateUploadUrl
{"requestID": "A1B2C3D4...", "type": 0, "expire": 300}
→ uploadUrl

// 6. 上传文件
POST {uploadUrl} (multipart/form-data)
→ fileKey

// 7. 发起签署
POST /esign-signs/v1/signFlow/createAndStart
{"subject": "劳动合同签署-苏枕雪", "businessNo": "hr_xxx", "businessTypeCode": "...", "initiatorInfo": {...}, "signFiles": [...], "signerInfos": [...]}
→ signFlowId, signUrl

// 8. 用户打开 signUrl 完成签署

// 9. 删除文件（签署完成后）
POST /esign-docs/v1/cus/file/delete
{"fileKey": "..."}
```

---

## 附录

### 证件类型枚举

| 枚举值 | 说明 |
|--------|------|
| ID_CARD | 身份证 |
| HK_MACAO | 港澳居民来往内地通行证 |
| TAIWAN | 台湾居民来往大陆通行证 |
| PASSPORT | 护照 |
| OTHER | 其他 |

### 印章类型枚举

| 枚举值 | 说明 |
|--------|------|
| COMMON-SEAL | 公章 |
| LEGAL-PERSON-SEAL | 法人章 |
| CONTRACT-SEAL | 合同章 |
| FINANCE-SEAL | 财务章 |

### 业务错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 200 | 成功 |
| 1123456 | 参数错误 |
| 其他 | 具体见错误信息 |
